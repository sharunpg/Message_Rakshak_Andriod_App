package com.example.scammessagecheck;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> historyList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        listView = findViewById(R.id.historyListView);

        historyList = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                historyList
        );

        listView.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadHistory();
    }

    private void loadHistory() {

        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        Gson gson = new Gson();

        String json = prefs.getString("history", null);

        if (json != null) {
            Type type = new TypeToken<ArrayList<String>>() {}.getType();
            historyList.clear();
            historyList.addAll(gson.fromJson(json, type));
        } else {
            historyList.clear();
        }

        adapter.notifyDataSetChanged();
    }
}