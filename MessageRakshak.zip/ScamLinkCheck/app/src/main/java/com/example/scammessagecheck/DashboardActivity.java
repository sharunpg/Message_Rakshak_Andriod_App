package com.example.scammessagecheck;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    TextView totalText, safeText, spamText, dangerText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        totalText = findViewById(R.id.totalText);
        safeText = findViewById(R.id.safeText);
        spamText = findViewById(R.id.spamText);
        dangerText = findViewById(R.id.dangerText);

        int safe = getIntent().getIntExtra("safe", 0);
        int spam = getIntent().getIntExtra("spam", 0);
        int danger = getIntent().getIntExtra("danger", 0);

        int total = safe + spam + danger;

        totalText.setText("Total Scanned: " + total);

        safeText.setText("Safe: " + safe);
        safeText.setTextColor(Color.parseColor("#2E7D32")); // Green

        spamText.setText("Spam: " + spam);
        spamText.setTextColor(Color.parseColor("#EF6C00")); // Orange

        dangerText.setText("Dangerous: " + danger);
        dangerText.setTextColor(Color.parseColor("#C62828")); // Red
    }
}