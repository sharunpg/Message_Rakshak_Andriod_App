package com.example.scammessagecheck;

import java.util.Arrays;
import java.util.List;

public class ScamDatabase {

    private static final List<String> scamSites = Arrays.asList(
            "fakebank.com",
            "secure-login-alert.com",
            "verify-account-now.net",
            "free-money.xyz",
            "lottery-winner.click",
            "phishing-site.com",
            "paypal-security-alert.com",
            "account-verification-required.net"
    );

    public static boolean isScam(String url) {
        for (String site : scamSites) {
            if (url.toLowerCase().contains(site)) {
                return true;
            }
        }
        return false;
    }
}