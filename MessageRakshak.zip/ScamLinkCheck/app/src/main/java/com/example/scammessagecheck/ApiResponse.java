package com.example.scammessagecheck;

public class ApiResponse {
    public Object matches;
}