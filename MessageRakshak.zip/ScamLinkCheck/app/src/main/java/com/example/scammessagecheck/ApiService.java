package com.example.scammessagecheck;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiService {

    @POST("v4/threatMatches:find")
    Call<ApiResponse> checkUrl(
            @Query("key") String apiKey,
            @Body ApiRequest request
    );
}