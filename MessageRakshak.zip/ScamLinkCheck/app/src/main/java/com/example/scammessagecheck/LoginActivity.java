package com.example.scammessagecheck;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText phone, password, confirmPassword;
    Button loginBtn;
    TextView switchText;

    boolean isSignup = false;

    SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phone = findViewById(R.id.phoneInput);
        password = findViewById(R.id.passwordInput);
        confirmPassword = findViewById(R.id.confirmPassword);
        loginBtn = findViewById(R.id.loginBtn);
        switchText = findViewById(R.id.switchText);

        prefs = getSharedPreferences("UserData", MODE_PRIVATE);

        boolean isLoggedIn = prefs.getBoolean("isLoggedIn", false);

        if (isLoggedIn) {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            finish();
        }

        switchText.setOnClickListener(v -> {

            isSignup = !isSignup;

            if (isSignup) {
                confirmPassword.setVisibility(View.VISIBLE);
                loginBtn.setText("Sign Up");
                switchText.setText("Already user? Login");
            } else {
                confirmPassword.setVisibility(View.GONE);
                loginBtn.setText("Login");
                switchText.setText("New user? Sign Up");
            }
        });

        loginBtn.setOnClickListener(v -> {

            String ph = phone.getText().toString().trim();
            String pass = password.getText().toString().trim();
            String confirm = confirmPassword.getText().toString().trim();

            if (ph.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            if (isSignup) {

                if (!pass.equals(confirm)) {
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                    return;
                }

                prefs.edit()
                        .putString("phone", ph)
                        .putString("password", pass)
                        .putBoolean("isLoggedIn", true)
                        .apply();

                Toast.makeText(this, "Signup successful", Toast.LENGTH_SHORT).show();

                startActivity(new Intent(this, MainActivity.class));
                finish();
            }

            else {

                String savedPhone = prefs.getString("phone", "");
                String savedPass = prefs.getString("password", "");

                if (!ph.equals(savedPhone) || !pass.equals(savedPass)) {
                    Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
                    return;
                }

                prefs.edit()
                        .putBoolean("isLoggedIn", true)
                        .apply();

                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

                startActivity(new Intent(this, MainActivity.class));
                finish();
            }
        });
    }
}