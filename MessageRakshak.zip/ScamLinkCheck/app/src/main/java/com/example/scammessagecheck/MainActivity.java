package com.example.scammessagecheck;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    EditText messageInput;
    Button analyzeBtn, dashboardBtn, historyBtn, logoutBtn, clearHistoryBtn;
    TextView resultText;

    ArrayList<String> historyList;

    int safe = 0, promo = 0, danger = 0;

    private static final String API_KEY = "YOUR_API_KEY_HERE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        messageInput = findViewById(R.id.messageInput);
        analyzeBtn = findViewById(R.id.analyzeBtn);
        resultText = findViewById(R.id.resultText);
        dashboardBtn = findViewById(R.id.dashboardBtn);
        historyBtn = findViewById(R.id.historyBtn);
        logoutBtn = findViewById(R.id.logoutBtn);
        clearHistoryBtn = findViewById(R.id.clearHistoryBtn);

        historyList = new ArrayList<>();
        loadHistory();

        analyzeBtn.setOnClickListener(v -> analyzeMessage());

        dashboardBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
            intent.putExtra("safe", safe);
            intent.putExtra("spam", promo);
            intent.putExtra("danger", danger);
            startActivity(intent);
        });

        historyBtn.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, HistoryActivity.class))
        );

        logoutBtn.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("UserData", MODE_PRIVATE);
            prefs.edit().putBoolean("isLoggedIn", false).apply();

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
        clearHistoryBtn.setOnClickListener(v -> {

            SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
            prefs.edit().remove("history").apply();

            historyList.clear();

            Toast.makeText(this, "History Cleared", Toast.LENGTH_SHORT).show();
        });
    }

    private void analyzeMessage() {

        String msg = messageInput.getText().toString().trim();

        if (msg.isEmpty()) {
            resultText.setText("⚠️ Please enter a message");
            resultText.setTextColor(getResources().getColor(android.R.color.darker_gray));
            return;
        }

        String keywordResult = SmartDetector.analyzeMessage(msg);
        String url = SmartDetector.extractUrl(msg);

        if (url != null) {

            ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
            ApiRequest request = new ApiRequest(url);

            apiService.checkUrl(API_KEY, request)
                    .enqueue(new Callback<ApiResponse>() {

                        @Override
                        public void onResponse(Call<ApiResponse> call, Response<ApiResponse> response) {

                            if (response.body() != null && response.body().matches != null) {

                                showResult("🚨 Dangerous Link Detected", android.R.color.holo_red_dark);
                                danger++;

                                saveToHistory(msg, "DANGEROUS");

                            } else {
                                applyKeywordResult(keywordResult, msg);
                            }
                        }

                        @Override
                        public void onFailure(Call<ApiResponse> call, Throwable t) {
                            applyKeywordResult(keywordResult, msg);
                        }
                    });

        } else {
            applyKeywordResult(keywordResult, msg);
        }
    }

    private void applyKeywordResult(String result, String msg) {

        switch (result) {

            case "DANGEROUS":
                showResult("🚨 Scam / Dangerous Message", android.R.color.holo_red_dark);
                danger++;
                break;

            case "PROMOTIONAL":
                showResult("📢 Promotional Message", android.R.color.holo_orange_dark);
                promo++;
                break;

            default:
                showResult("✅ Safe Message", android.R.color.holo_green_dark);
                safe++;
                break;
        }

        saveToHistory(msg, result);
    }

    private void showResult(String text, int color) {
        resultText.setText(text);
        resultText.setTextColor(getResources().getColor(color));
    }

    private void saveToHistory(String msg, String result) {
        historyList.add(msg + " → " + result);
        saveHistory();
    }

    private void saveHistory() {
        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = gson.toJson(historyList);
        prefs.edit().putString("history", json).apply();
    }

    private void loadHistory() {
        SharedPreferences prefs = getSharedPreferences("data", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = prefs.getString("history", null);

        if (json != null) {
            Type type = new TypeToken<ArrayList<String>>() {}.getType();
            historyList = gson.fromJson(json, type);
        } else {
            historyList = new ArrayList<>();
        }
    }
}