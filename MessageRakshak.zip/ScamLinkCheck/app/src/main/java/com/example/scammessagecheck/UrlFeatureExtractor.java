package com.example.scammessagecheck;

public class UrlFeatureExtractor {

    public static float[] extractFeatures(String url) {

        float length = url.length();

        float hasAt = url.contains("@") ? 1 : 0;

        float hasHyphen = url.contains("-") ? 1 : 0;

        float hasHttps = url.startsWith("https") ? 1 : 0;

        float hasLogin = url.toLowerCase().contains("login") ? 1 : 0;

        float hasVerify = url.toLowerCase().contains("verify") ? 1 : 0;

        float hasNumber = url.matches(".*\\d.*") ? 1 : 0;

        return new float[]{
                length,
                hasAt,
                hasHyphen,
                hasHttps,
                hasLogin,
                hasVerify,
                hasNumber
        };
    }
}