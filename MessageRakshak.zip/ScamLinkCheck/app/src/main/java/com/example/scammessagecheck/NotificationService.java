package com.example.scammessagecheck;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.os.Bundle;
import android.widget.Toast;

public class NotificationService extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {

        Notification notification = sbn.getNotification();
        Bundle extras = notification.extras;

        String title = extras.getString(Notification.EXTRA_TITLE);
        CharSequence textChar = extras.getCharSequence(Notification.EXTRA_TEXT);

        String text = textChar != null ? textChar.toString() : "";

        if (isScam(text)) {
            Toast.makeText(getApplicationContext(),
                    "⚠️ Scam Notification Detected!",
                    Toast.LENGTH_LONG).show();
        }
    }

    private boolean isScam(String text) {

        text = text.toLowerCase();

        return text.contains("otp") ||
                text.contains("urgent") ||
                text.contains("verify") ||
                text.contains("bank") ||
                text.contains("click link") ||
                text.contains("account blocked") ||
                text.contains("update details");
    }
}