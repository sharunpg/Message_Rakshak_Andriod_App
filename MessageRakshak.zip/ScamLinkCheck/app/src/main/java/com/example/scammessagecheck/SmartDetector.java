package com.example.scammessagecheck;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SmartDetector {

    public static String analyzeMessage(String text) {

        text = text.toLowerCase();
        int score = 0;

        String[] highRisk = {
                "otp", "password", "verify your account",
                "bank alert", "account blocked",
                "login immediately", "confirm identity"
        };

        for (String word : highRisk) {
            if (text.contains(word)) {
                score += 3;
            }
        }

        String[] mediumRisk = {
                "click here", "urgent", "update details",
                "limited time", "act now", "offer expires"
        };

        for (String word : mediumRisk) {
            if (text.contains(word)) {
                score += 2;
            }
        }

        String url = extractUrl(text);
        if (url != null) {
            score += 2;
        }

        String[] promo = {
                "offer", "sale", "discount",
                "free", "%", "buy now"
        };

        for (String word : promo) {
            if (text.contains(word)) {
                score += 1;
            }
        }

        if (text.matches(".*[!@#$%^&*]{3,}.*")) {
            score += 1;
        }

        if (text.equals(text.toUpperCase()) && text.length() > 10) {
            score += 1;
        }

        if (score >= 5) {
            return "DANGEROUS";
        } else if (score >= 3) {
            return "PROMOTIONAL";
        } else {
            return "SAFE";
        }
    }

    public static String extractUrl(String text) {

        Pattern pattern = Pattern.compile(
                "(https?:\\/\\/[^\\s]+)|(www\\.[^\\s]+)|(\\b\\w+\\.(com|org|net|in|co)\\b)",
                Pattern.CASE_INSENSITIVE
        );

        Matcher matcher = pattern.matcher(text);

        if (matcher.find()) {
            return matcher.group();
        }

        return null;
    }
}