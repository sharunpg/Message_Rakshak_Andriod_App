package com.example.scammessagecheck;

import java.util.Arrays;

public class ApiRequest {

    public Client client = new Client();
    public ThreatInfo threatInfo;

    public ApiRequest(String url) {
        threatInfo = new ThreatInfo(url);
    }

    class Client {
        public String clientId = "message-rakshak";
        public String clientVersion = "1.0";
    }

    class ThreatInfo {
        public String[] threatTypes = {"MALWARE", "SOCIAL_ENGINEERING"};
        public String[] platformTypes = {"ANY_PLATFORM"};
        public String[] threatEntryTypes = {"URL"};
        public ThreatEntry[] threatEntries;

        public ThreatInfo(String url) {
            threatEntries = new ThreatEntry[]{new ThreatEntry(url)};
        }
    }

    class ThreatEntry {
        public String url;

        public ThreatEntry(String url) {
            this.url = url;
        }
    }
}